package com.example.newnewnewfb;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthException;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private EditText etname;
    private EditText etage;
    private TextView tvname;
    private TextView tvage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        etname= findViewById(R.id.etname);
        etage= findViewById(R.id.etage);
         tvname= findViewById(R.id.tvName);
         tvage= findViewById(R.id.tvAge);

       /* FirebaseAuth.getInstance().createUserWithEmailAndPassword("raboyester@gmail.com", "ketemM4080")
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {

                    }
                });*/

         FirebaseDatabase database= FirebaseDatabase.getInstance("https://newnewnewfb-ee5fa-default-rtdb.firebaseio.com/");
        DatabaseReference myRef= database.getReference("name");
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String name= snapshot.getValue(String.class);
                tvname.setText("name: "+name);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(MainActivity.this, "Error reading from firebase",Toast.LENGTH_LONG).show();
            }
        });

       myRef= database.getReference("age");
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                int age= snapshot.getValue(int.class);
                tvage.setText("age: "+age);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(MainActivity.this, "Error reading from firebase",Toast.LENGTH_LONG).show();
            }
        });

        myRef= database.getReference("user");
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                User user= snapshot.getValue(User.class);
                 tvname.setText("name: "+user.getName());
                 tvage.setText("age: "+user.getAge());

            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(MainActivity.this, "Error reading from firebase",Toast.LENGTH_LONG).show();
            }
        });



      final RecyclerView recyclerView= findViewById(R.id.recycleview_users);
       RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

       final ArrayList<User> users= new ArrayList<>();
        final UserAdapter adapter= new UserAdapter(users);
        recyclerView.setAdapter(adapter);


        myRef= database.getReference("users");
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                users.clear();
                for( DataSnapshot userSnapshot : snapshot.getChildren()) {
                    User currentUser = userSnapshot.getValue(User.class);
                    users.add(currentUser);
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(MainActivity.this, "error reading the firebase",Toast.LENGTH_LONG).show();
            }
        });
    }

    public void saveName(View view) {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("name");

        myRef.setValue(etname.getText().toString());
    }

    public void saveAge(View view) {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("age");

        myRef.setValue(Integer.parseInt(etage.getText().toString()));
    }

    public void saveUser(View view) {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("user");

        User user= new User(etname.getText().toString(),Integer.parseInt(etage.getText().toString()));
        myRef.setValue(user);
    }

    public void addUser(View view) {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("users/123").push();

        User user= new User(etname.getText().toString(),Integer.parseInt(etage.getText().toString()));
        myRef.setValue(user);
    }
}